import nodemailer from 'nodemailer';

// Create transporter once (reuse connection pool)
const createTransporter = () => {
  const port = Number(process.env.EMAIL_PORT) || 587;
  return nodemailer.createTransport({
    host: process.env.EMAIL_HOST,
    port,
    secure: port === 465, // true for 465, false for 587
    auth: {
      user: process.env.EMAIL_USER,
      pass: process.env.EMAIL_PASS,
    },
    // Production timeouts
    connectionTimeout: 10000,
    greetingTimeout:   10000,
    socketTimeout:     30000,
    // TLS options
    tls: {
      rejectUnauthorized: process.env.NODE_ENV === 'production',
    },
  });
};

export const sendEmail = async ({ to, subject, html }) => {
  const transporter = createTransporter();

  const mailOptions = {
    from: `"Miskara Jewellery" <${process.env.EMAIL_USER}>`,
    to,
    subject,
    html,
    // Plain text fallback
    text: html.replace(/<[^>]*>/g, '').replace(/\s+/g, ' ').trim(),
  };

  try {
    const info = await transporter.sendMail(mailOptions);
    console.log(`📧 Email sent to ${to} | MessageId: ${info.messageId}`);
    return info;
  } catch (err) {
    console.error(`❌ Email failed to ${to}:`, err.message);
    // Don't throw — email failure should not crash the request
    // Caller handles it
    throw err;
  }
};

// Test connection on startup (optional — call in server.js if needed)
export const verifyEmailConnection = async () => {
  try {
    const t = createTransporter();
    await t.verify();
    console.log('✅ Email server connection verified');
    return true;
  } catch (err) {
    console.error('⚠️  Email server connection failed:', err.message);
    return false;
  }
};
